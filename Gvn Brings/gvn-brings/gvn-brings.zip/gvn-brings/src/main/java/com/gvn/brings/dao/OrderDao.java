package com.gvn.brings.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gvn.brings.dto.OrderDto;
import com.gvn.brings.dto.RegistrationDto;
import com.gvn.brings.model.BrngLkpIsPaid;
import com.gvn.brings.model.BrngLkpPayPercent;
import com.gvn.brings.model.BrngLkpUsrRegType;
import com.gvn.brings.model.BrngOrder;
import com.gvn.brings.model.BrngUsrReg;

@Transactional
@Repository
public class OrderDao {

	@PersistenceContext
    private EntityManager manager;
	
	public List<OrderDto> getpayPercent(){
		List<BrngLkpPayPercent> brngLkpPayPercents = manager.createQuery("Select a From BrngLkpPayPercent a",BrngLkpPayPercent.class).
				getResultList();
		List<OrderDto> dtoList = new ArrayList();
		OrderDto orderDto = null;
		for(BrngLkpPayPercent brngLkpPayPercent:brngLkpPayPercents){
			orderDto = new OrderDto(brngLkpPayPercent);
			dtoList.add(orderDto);
		}
		return dtoList;
	}
	
	public List<OrderDto> getIsPaidTypes(){
		List<BrngLkpIsPaid> brngLkpIsPaidTypes = manager.createQuery("Select a From BrngLkpIsPaid a",BrngLkpIsPaid.class).
				getResultList();
		List<OrderDto> dtoList = new ArrayList();
		OrderDto orderDto = null;
		for(BrngLkpIsPaid brngLkpIsPaid:brngLkpIsPaidTypes){
			orderDto = new OrderDto(brngLkpIsPaid);
			dtoList.add(orderDto);
		}
		return dtoList;
	}
	
	public int bookAnOrder(BrngOrder brngorder){
		/* Query query = manager.createNativeQuery("INSERT INTO BRNG_USR_REG (address, email_id,first_name,last_name,middle_name,password,usr_reg_type_id,usr_reg_status_id) " +
		            " VALUES(?,?,?,?,?,?,?,?)");
		        query.setParameter(1, brngusrreg.getAddress());
		        query.setParameter(2, brngusrreg.getEmailId());
		        query.setParameter(3, brngusrreg.getFirstName());
		        query.setParameter(4, brngusrreg.getLastName());
		        query.setParameter(5, brngusrreg.getMiddleName());
		        query.setParameter(6, brngusrreg.getPassword());
		        query.setParameter(7, 1);
		        query.setParameter(8, 2);
		       int response= query.executeUpdate();
		       return response;*/
		//EntityTransaction transaction=null;
		Timestamp ts=new Timestamp(System.currentTimeMillis());
		try
		{
		/* transaction = manager.getTransaction();
		transaction.begin();*/
			brngorder.setOrderTime(ts);
		manager.persist(brngorder);
		//transaction.commit();
		return 1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//transaction.rollback();
			return 0;
		}
		
	}
}
