package com.gvn.brings.dao;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gvn.brings.dto.RegistrationDto;

import com.gvn.brings.dto.TestDto;

import com.gvn.brings.model.BrngLkpUsrRegStatus;
import com.gvn.brings.model.BrngLkpUsrRegType;
import com.gvn.brings.model.BrngLkpUsrType;
import com.gvn.brings.model.BrngUsrReg;

@Transactional
@Repository
public class RegistrationDao extends AbstractBaseDao{
	@PersistenceContext
    private EntityManager manager;
	
	public List<RegistrationDto> getUserRegTypeList(){
		List<BrngLkpUsrRegType> brngLkpUsrRegTypes = manager.createQuery("Select a From BrngLkpUsrRegType a",BrngLkpUsrRegType.class).
				getResultList();
		List<RegistrationDto> dtoList = new ArrayList();
		RegistrationDto registrationDto = null;
		for(BrngLkpUsrRegType brngLkpUsrRegType:brngLkpUsrRegTypes){
			registrationDto = new RegistrationDto(brngLkpUsrRegType);
			dtoList.add(registrationDto);
		}
		return dtoList;
	}
	
	public List<RegistrationDto> getUserRegStatusList(){
		List<BrngLkpUsrRegStatus> brngLkpUsrRegStatuses = manager.createQuery("Select a From BrngLkpUsrRegStatus a",BrngLkpUsrRegStatus.class).
				getResultList();
		List<RegistrationDto> dtoList = new ArrayList();
		RegistrationDto registrationDto = null;
		for(BrngLkpUsrRegStatus brngLkpUsrRegStatus:brngLkpUsrRegStatuses){
			registrationDto = new RegistrationDto(brngLkpUsrRegStatus);
			dtoList.add(registrationDto);
		}
		return dtoList;
	}
	
	public List<RegistrationDto> getUserTypeList(){
		List<BrngLkpUsrType> brngLkpUsrTypes = manager.createQuery("Select a From BrngLkpUsrType a",BrngLkpUsrType.class).
				getResultList();
		List<RegistrationDto> dtoList = new ArrayList();
		RegistrationDto registrationDto = null;
		for(BrngLkpUsrType brngLkpUsrType:brngLkpUsrTypes){
			registrationDto = new RegistrationDto(brngLkpUsrType);
			dtoList.add(registrationDto);
		}
		return dtoList;
	}
	
	
	public int registerUser(BrngUsrReg brngusrreg){
		/* Query query = manager.createNativeQuery("INSERT INTO BRNG_USR_REG (address, email_id,first_name,last_name,middle_name,password,usr_reg_type_id,usr_reg_status_id) " +
		            " VALUES(?,?,?,?,?,?,?,?)");
		        query.setParameter(1, brngusrreg.getAddress());
		        query.setParameter(2, brngusrreg.getEmailId());
		        query.setParameter(3, brngusrreg.getFirstName());
		        query.setParameter(4, brngusrreg.getLastName());
		        query.setParameter(5, brngusrreg.getMiddleName());
		        query.setParameter(6, brngusrreg.getPassword());
		        query.setParameter(7, 1);
		        query.setParameter(8, 2);
		       int response= query.executeUpdate();
		       return response;*/
		//EntityTransaction transaction=null;
		Timestamp registeredTime=new Timestamp(System.currentTimeMillis());
		brngusrreg.setRegisteredDate(registeredTime);
		try
		{
		/* transaction = manager.getTransaction();
		transaction.begin();*/
		manager.persist(brngusrreg);
		//transaction.commit();
		return 1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//transaction.rollback();
			return 0;
		}
		
	}
	
	
	public List<RegistrationDto> getProfileDetails(String email){
		List<BrngUsrReg> brngUsrRegDetails = manager.createQuery("Select a From BrngUsrReg a",BrngUsrReg.class).
				getResultList();
		List<RegistrationDto> dtoList = new ArrayList();
		RegistrationDto registrationDto = null;
		for(BrngUsrReg brngUsrRegDetail:brngUsrRegDetails){
			registrationDto = new RegistrationDto(brngUsrRegDetail);
			dtoList.add(registrationDto);
		}
		return dtoList;
	}
	
	public 	int updateProfile(BrngUsrReg brngusrreg) throws SQLException, ClassNotFoundException
	{
		try
		{
		String password = null;
		Query query = manager
				.createQuery("UPDATE BrngUsrReg a SET a.firstName = :firstName,a.lastName=:lastName,a.middleName=:middleName "
				+ "WHERE a.emailId= :email");
				query.setParameter("firstName", brngusrreg.getFirstName());
				query.setParameter("lastName", brngusrreg.getLastName());
				query.setParameter("middleName", brngusrreg.getMiddleName());
				
				query.setParameter("email",brngusrreg.getEmailId());
				query.executeUpdate();
				return 1;
				}
	catch(Exception e){
			e.printStackTrace();
			return 0;
		}  
		finally{
			
		} 
		
			
	}
	
}
