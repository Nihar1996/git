package com.gvn.brings.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.gvn.brings.dto.OrderDto;
import com.gvn.brings.dto.RegistrationDto;
import com.gvn.brings.model.BrngOrder;
import com.gvn.brings.services.OrderService;
import com.gvn.brings.services.RegistrationService;

@RestController
public class OrderController extends AbstractBaseController{

	@Autowired
	private OrderService orderService;
	@RequestMapping(value = REST+"payPercent", method = RequestMethod.GET,headers="Accept=application/json")
	public List<OrderDto> getPayPercent(){
		return orderService.getPayPercent();
	}
	
	@RequestMapping(value = REST+"isPaidTypes", method = RequestMethod.GET,headers="Accept=application/json")
	public List<OrderDto> getIsPaidTypes(){
		return orderService.getIsPaidTypes();
	}
	@RequestMapping(value = REST+"bookAnOrder", method = RequestMethod.POST,headers="Accept=application/json")
	public int getIsPaidTypes(@RequestBody BrngOrder brngorder){
		return orderService.bookAnOrder(brngorder);
	}
}
