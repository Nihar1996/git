package com.gvn.brings.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.gvn.brings.model.BrngLkpIsPaid;
import com.gvn.brings.model.BrngLkpPayPercent;

public class OrderDto extends AbstractBaseDto{
	private static final long serialVersionUID = 1L;
	
	private BigDecimal payPercent;
	private Date effectiveDate;
	private String description;
	private String isPaid;
	
	
	public OrderDto(BrngLkpPayPercent brngLkpPayPercent)
	{
		this.payPercent=brngLkpPayPercent.getPayPercent();
		this.effectiveDate=brngLkpPayPercent.getEffectiveDate();
		this.description=brngLkpPayPercent.getDescription();
	}
	
	public OrderDto(BrngLkpIsPaid brngLkpIsPaid)
	{
		this.isPaid=brngLkpIsPaid.getIsPaid();
		this.description=brngLkpIsPaid.getDescription();
	}
	public BigDecimal getPayPercent() {
		return payPercent;
	}
	public void setPayPercent(BigDecimal payPercent) {
		this.payPercent = payPercent;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getIsPaid() {
		return isPaid;
	}

	public void setIsPaid(String isPaid) {
		this.isPaid = isPaid;
	}
	
}
