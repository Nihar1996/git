package com.gvn.brings.dto;

import com.gvn.brings.model.BrngLkpUsrRegStatus;
import com.gvn.brings.model.BrngLkpUsrRegType;
import com.gvn.brings.model.BrngLkpUsrType;
import com.gvn.brings.model.BrngUsrReg;

public class RegistrationDto extends AbstractBaseDto{
	private static final long serialVersionUID = 1L;
	
	private String usrRegType;
	private String description;
	private String usrRegStatus;
	private String userType;
	
	//For User Details
	
	private BrngUsrReg brngUsrReg;
	
	
	public RegistrationDto(BrngUsrReg brngUsrReg ){
		this.brngUsrReg = brngUsrReg;
		
	}
	
	public RegistrationDto(BrngLkpUsrRegStatus brngLkpUsrRegStatus ){
		this.usrRegStatus = brngLkpUsrRegStatus.getStatusType();
		this.description = brngLkpUsrRegStatus.getDescription();
	}
	
	public RegistrationDto(BrngLkpUsrType brngLkpUsrType ){
		this.userType = brngLkpUsrType.getUsrType();
		this.description = brngLkpUsrType.getDescription();
	}
	
	public RegistrationDto(BrngLkpUsrRegType brngLkpUsrRegType){
		this.usrRegType = brngLkpUsrRegType.getUsrRegType();
		this.description = brngLkpUsrRegType.getDescription();
	}

	public String getUsrRegType() {
		return usrRegType;
	}

	public void setUsrRegType(String usrRegType) {
		this.usrRegType = usrRegType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	public String getUsrRegStatus() {
		return usrRegStatus;
	}

	public void setUsrRegStatus(String usrRegStatus) {
		this.usrRegStatus = usrRegStatus;
	}
	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}
	
	
}
