package com.gvn.brings.web.controller;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.gvn.brings.dto.RegistrationDto;
import com.gvn.brings.model.BrngUsrReg;
import com.gvn.brings.services.RegistrationService;

@RestController
public class RegistrationController extends AbstractBaseController{

	@Autowired
	private RegistrationService registrationService;
	
	@RequestMapping(value = REST+"usrRegType", method = RequestMethod.GET,headers="Accept=application/json")
	public List<RegistrationDto> getUserRegType(){
		return registrationService.getUserRegType();
	}
	@RequestMapping(value = REST+"userRegStatus", method = RequestMethod.GET,headers="Accept=application/json")
	public List<RegistrationDto> getUserRegStatus(){
		return registrationService.getUserRegStatus();
	}
	@RequestMapping(value = REST+"usrType", method = RequestMethod.GET,headers="Accept=application/json")
	public List<RegistrationDto> getUserType(){
		return registrationService.getUserType();
	}
	@RequestMapping(value = REST+"usrReg", method = RequestMethod.POST,headers="Accept=application/json")
	public int registerUser(@RequestBody BrngUsrReg brngusrreg){
		return registrationService.registerUser(brngusrreg);
	}
	@RequestMapping(value = REST+"getProfileById", method = RequestMethod.POST,headers="Accept=application/json")
	public List<RegistrationDto> getProfileDetails(@RequestBody HashMap<String, String> details){
		return registrationService.getProfileDetails(details.get("email"));
	}
	@RequestMapping(value = REST+"updateProfile", method = RequestMethod.POST,headers="Accept=application/json")
	public int  updateProfile(@RequestBody BrngUsrReg brngUsrReg) throws ClassNotFoundException, SQLException{
		return registrationService.updateProfile(brngUsrReg);
	}
	
}
 