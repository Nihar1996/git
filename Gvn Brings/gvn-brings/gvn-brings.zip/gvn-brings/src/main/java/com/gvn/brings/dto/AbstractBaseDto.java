package com.gvn.brings.dto;

import java.io.Serializable;

public abstract class AbstractBaseDto implements Serializable{

	private static final long serialVersionUID = 1L;

}
