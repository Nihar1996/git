package com.gvn.brings.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gvn.brings.dto.OrderDto;
import com.gvn.brings.model.BrngLkpPayPercent;
import com.gvn.brings.model.BrngUsrLogin;
import com.gvn.brings.model.BrngUsrPassChange;
import com.gvn.brings.model.BrngUsrReg;
import com.gvn.brings.util.MailUtility;
import com.gvn.brings.util.TempPasswordUtil;

@Transactional
@Repository
public class LoginDao extends AbstractBaseDao{

	@PersistenceContext
    private EntityManager manager;
	public int loginUser(BrngUsrLogin brngusrlogin){
		try
		{
		 Timestamp loginTime=new Timestamp(System.currentTimeMillis());
		Query query = manager.
			      createQuery("Select count(brngUsrReg) from BrngUsrLogin where brngUsrReg="+brngusrlogin.getBrngUsrReg());
				long count = (long)query.getSingleResult();
				
				if(count>0)
				{
				 query = manager
							.createQuery("UPDATE BrngUsrLogin a SET a.loginTime = :loginTime "
							+ "WHERE a.BrngUsrReg.id= :id");
							query.setParameter("id", brngusrlogin.getBrngUsrReg().getId());
							query.setParameter("loginTime",loginTime);
								query.executeUpdate();
				}
				else
				{
					System.out.println(brngusrlogin.getBrngUsrReg().getId());
					brngusrlogin.setLoginTime(loginTime);
					//brngusrlogin.setBrngUsrReg(brngusrlogin.getBrngUsrReg());
					manager.persist(brngusrlogin);
				}
		       int response= query.executeUpdate();
		       return 1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}
	
	public  int sendPasswordToMail(BrngUsrReg brngusrreg) throws SQLException{
		
		try
		{
			String email=brngusrreg.getEmailId();
		String password = null;
		Query query = manager.
			      createQuery("SELECT id  FROM BrngUsrReg WHERE emailId = '"+email+"'");
		List<Integer> results = query.getResultList();
				if(results.size()>0)
				{
					   Date date = new Date();
		               
		                DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		               
		                //to convert Date to String, use format method of SimpleDateFormat class.
		                String strDate = dateFormat.format(date);
					TempPasswordUtil gtp=new TempPasswordUtil();
					 password=gtp.getPassword();
					 BrngUsrPassChange brngUsrPassChange =new BrngUsrPassChange();
					 BrngUsrReg brngUsrReg=new BrngUsrReg();
					 brngUsrReg.setId(results.get(0));
					 brngUsrPassChange.setBrngUsrReg(brngUsrReg);
					 brngUsrPassChange.setEffectiveDate(strDate);
					 brngUsrPassChange.setPassword(password);
					 
					 manager.persist(brngUsrPassChange);
					 MailUtility mailutility=new  MailUtility();
					 mailutility.sendEmail(email, password);
				return 1;
				}
		
				
			
	
		}catch(Exception e){
			e.printStackTrace();
			return 0;
		}  
		finally{
			
		}  
		
		return 0;	 
	}
	
	
	public 	int changePassword(BrngUsrReg brngusrreg) throws SQLException, ClassNotFoundException
	{
		try
		{
		String password = null;
		Query query = manager
				.createQuery("UPDATE BrngUsrReg a SET a.password = :password "
				+ "WHERE a.emailId= :email");
				query.setParameter("password", brngusrreg.getPassword());
				query.setParameter("email",brngusrreg.getEmailId());
				query.executeUpdate();
				return 1;
				}
	catch(Exception e){
			e.printStackTrace();
			return 0;
		}  
		finally{
			
		} 
		
			
	}
	
	
	public 	int logoutUser(BrngUsrReg brngUsrReg) throws SQLException, ClassNotFoundException
	{	try
	{
	String password = null;
	Timestamp logOutTime=new Timestamp(System.currentTimeMillis());
	Query query = manager.
		      createQuery("SELECT id  FROM BrngUsrReg WHERE emailId = '"+brngUsrReg.getEmailId()+"'");
	List<Integer> results = query.getResultList();
	 query = manager
			.createQuery("UPDATE BrngUsrLogin a SET a.logoutTime = :time "
			+ "WHERE a.BrngUsrReg.id= :id");
			query.setParameter("time", logOutTime);
			query.setParameter("id",results.get(0));
			query.executeUpdate();
			return 1;
			}
catch(Exception e){
		e.printStackTrace();
		return 0;
	}  
	finally{
		
	} 


	}
}
