package com.gvn.brings.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gvn.brings.dao.OrderDao;
import com.gvn.brings.dao.OrderDeliveryDao;
import com.gvn.brings.dto.OrderDeliveryDto;
import com.gvn.brings.dto.OrderDto;
import com.gvn.brings.model.BrngOrderDelivery;

@Service("orderDeliveryService")
public class OrderDeliveryService extends AbstractBaseService{

	@Autowired
	private OrderDeliveryDao orderDeliveryDao;
	
	public List<OrderDeliveryDto> getIsAcceptedTypes(){
		return orderDeliveryDao.getIsAcceptedTypes();
	}
	public List<OrderDeliveryDto> getIsPickedTypes(){
		return orderDeliveryDao.getIsPickedTypes();
	}
	
	public List<OrderDeliveryDto> getOrderDelStatus(){
		return orderDeliveryDao.getOrderDelStatus();
	}
	public int acceptAnOrder(BrngOrderDelivery brngOrderDelivey){
		return orderDeliveryDao.acceptAnOrder(brngOrderDelivey);
	}
}
