package com.gvn.brings.services;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gvn.brings.dao.RegistrationDao;
import com.gvn.brings.dto.RegistrationDto;
import com.gvn.brings.model.BrngUsrReg;

@Service("registrationService")
public class RegistrationService extends AbstractBaseService{

	@Autowired
	private RegistrationDao registrationDao;
	
	public List<RegistrationDto> getUserRegType(){
		return registrationDao.getUserRegTypeList();
	}
	public List<RegistrationDto> getUserRegStatus(){
		return registrationDao.getUserRegStatusList();
	}
	public List<RegistrationDto> getUserType(){
		return registrationDao.getUserTypeList();
	}
	public int registerUser(BrngUsrReg brngusrreg){
		return registrationDao.registerUser(brngusrreg);
	}
	public List<RegistrationDto> getProfileDetails(String email){
		return registrationDao.getProfileDetails(email);
	}
	public int updateProfile(BrngUsrReg brngusrreg) throws ClassNotFoundException, SQLException{
		return registrationDao.updateProfile(brngusrreg);
	}
}
