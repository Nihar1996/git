package com.gvn.brings.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gvn.brings.dto.OrderDeliveryDto;
import com.gvn.brings.dto.RegistrationDto;
import com.gvn.brings.model.BrngLkpIsAccepted;
import com.gvn.brings.model.BrngLkpIsPicked;
import com.gvn.brings.model.BrngLkpOrderDelStatus;
import com.gvn.brings.model.BrngLkpUsrRegType;
import com.gvn.brings.model.BrngOrder;
import com.gvn.brings.model.BrngOrderDelivery;

@Transactional
@Repository
public class OrderDeliveryDao {
	@PersistenceContext
    private EntityManager manager;
	
	public List<OrderDeliveryDto> getIsAcceptedTypes(){
		List<BrngLkpIsAccepted> brngLkpIsAcceptedTypes = manager.createQuery("Select a From BrngLkpIsAccepted a",BrngLkpIsAccepted.class).
				getResultList();
		List<OrderDeliveryDto> dtoList = new ArrayList();
		OrderDeliveryDto orderDeliveryDto = null;
		for(BrngLkpIsAccepted brngLkpIsAcceptedType:brngLkpIsAcceptedTypes){
			orderDeliveryDto = new OrderDeliveryDto(brngLkpIsAcceptedType);
			dtoList.add(orderDeliveryDto);
		}
		return dtoList;
	}
	
	public List<OrderDeliveryDto> getIsPickedTypes(){
		List<BrngLkpIsPicked> brngLkpIsPickedTypes = manager.createQuery("Select a From BrngLkpIsPicked a",BrngLkpIsPicked.class).
				getResultList();
		List<OrderDeliveryDto> dtoList = new ArrayList();
		OrderDeliveryDto orderDeliveryDto = null;
		for(BrngLkpIsPicked brngLkpIsPickedType:brngLkpIsPickedTypes){
			orderDeliveryDto = new OrderDeliveryDto(brngLkpIsPickedType);
			dtoList.add(orderDeliveryDto);
		}
		return dtoList;
	}
	
	public List<OrderDeliveryDto> getOrderDelStatus(){
		List<BrngLkpOrderDelStatus> brngLkpOrderDelStatuses = manager.createQuery("Select a From BrngLkpOrderDelStatus a",BrngLkpOrderDelStatus.class).
				getResultList();
		List<OrderDeliveryDto> dtoList = new ArrayList();
		OrderDeliveryDto orderDeliveryDto = null;
		for(BrngLkpOrderDelStatus brngLkpOrderDelStatus:brngLkpOrderDelStatuses){
			orderDeliveryDto = new OrderDeliveryDto(brngLkpOrderDelStatus);
			dtoList.add(orderDeliveryDto);
		}
		return dtoList;
	}
	public int acceptAnOrder(BrngOrderDelivery brngorderdelivery){
		/* Query query = manager.createNativeQuery("INSERT INTO BRNG_USR_REG (address, email_id,first_name,last_name,middle_name,password,usr_reg_type_id,usr_reg_status_id) " +
		            " VALUES(?,?,?,?,?,?,?,?)");
		        query.setParameter(1, brngusrreg.getAddress());
		        query.setParameter(2, brngusrreg.getEmailId());
		        query.setParameter(3, brngusrreg.getFirstName());
		        query.setParameter(4, brngusrreg.getLastName());
		        query.setParameter(5, brngusrreg.getMiddleName());
		        query.setParameter(6, brngusrreg.getPassword());
		        query.setParameter(7, 1);
		        query.setParameter(8, 2);
		       int response= query.executeUpdate();
		       return response;*/
		//EntityTransaction transaction=null;
		Timestamp ts=new Timestamp(System.currentTimeMillis());
		try
		{
		/* transaction = manager.getTransaction();
		transaction.begin();*/
		
		manager.persist(brngorderdelivery);
		//transaction.commit();
		return 1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//transaction.rollback();
			return 0;
		}
		
	}

}
