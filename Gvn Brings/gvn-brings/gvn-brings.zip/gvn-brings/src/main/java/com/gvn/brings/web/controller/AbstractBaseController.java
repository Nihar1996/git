package com.gvn.brings.web.controller;

public abstract class AbstractBaseController {

	protected final String REST = "/rest/";
}
