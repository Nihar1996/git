package com.gvn.brings.model;

import java.io.Serializable;

public class AbstractBaseModel implements Serializable{

}
