package com.gvn.brings.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.gvn.brings.dto.OrderDeliveryDto;
import com.gvn.brings.dto.OrderDto;
import com.gvn.brings.model.BrngOrderDelivery;
import com.gvn.brings.services.OrderDeliveryService;
import com.gvn.brings.services.OrderService;

@RestController
public class OrderDeliveryController extends AbstractBaseController{

	@Autowired
	private OrderDeliveryService orderDelieveryService;
	
	@RequestMapping(value = REST+"isAcceptedTypes", method = RequestMethod.GET,headers="Accept=application/json")
	public List<OrderDeliveryDto> getIsAcceptedTypes(){
		return orderDelieveryService.getIsAcceptedTypes();
	}
	
	@RequestMapping(value = REST+"isPickedTypes", method = RequestMethod.GET,headers="Accept=application/json")
	public List<OrderDeliveryDto> getIsPickedTypes(){
		return orderDelieveryService.getIsPickedTypes();
	}
	
	@RequestMapping(value = REST+"orderDelStatus", method = RequestMethod.GET,headers="Accept=application/json")
	public List<OrderDeliveryDto> getOrderDelStatus(){
		return orderDelieveryService.getOrderDelStatus();
	}
	
	@RequestMapping(value = REST+"acceptAnOrder", method = RequestMethod.POST,headers="Accept=application/json")
	public int acceptAnOrder(@RequestBody BrngOrderDelivery brngOrderDelivey){
		return orderDelieveryService.acceptAnOrder(brngOrderDelivey);
	}
}
