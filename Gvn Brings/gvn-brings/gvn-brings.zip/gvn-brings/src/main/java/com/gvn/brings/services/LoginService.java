package com.gvn.brings.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gvn.brings.dao.LoginDao;
import com.gvn.brings.dao.RegistrationDao;
import com.gvn.brings.dto.RegistrationDto;
import com.gvn.brings.model.BrngUsrLogin;
import com.gvn.brings.model.BrngUsrReg;

@Service("loginService")
public class LoginService extends AbstractBaseService{

	@Autowired
	private LoginDao loginDao;
	
	public int loginUser(BrngUsrLogin brngusrlogin){
		return loginDao.loginUser(brngusrlogin);
	}
	
	public int sendPasswordToMail(BrngUsrReg brngUsrReg) throws SQLException{
		return loginDao.sendPasswordToMail(brngUsrReg);
	}
	
	public int changePassword(BrngUsrReg brngUsrReg) throws SQLException, ClassNotFoundException{
		return loginDao.changePassword(brngUsrReg);
	}
	public int logoutUser(BrngUsrReg brngUsrReg) throws SQLException, ClassNotFoundException{
		return loginDao.logoutUser(brngUsrReg);
	}
}
