package com.gvn.brings.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the BRNG_ORDER_DELIVERY_ATTR database table.
 * 
 */
@Entity
@Table(name="BRNG_ORDER_DELIVERY_ATTR")
@NamedQuery(name="BrngOrderDeliveryAttr.findAll", query="SELECT b FROM BrngOrderDeliveryAttr b")
public class BrngOrderDeliveryAttr extends AbstractBaseModel  {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false)
	private int id;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="effective_date")
	private Date effectiveDate;

	@Column(name="order_delivery_id", length=45)
	private String orderDeliveryId;

	public BrngOrderDeliveryAttr() {
	}

	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOrderDeliveryId() {
		return this.orderDeliveryId;
	}

	public void setOrderDeliveryId(String orderDeliveryId) {
		this.orderDeliveryId = orderDeliveryId;
	}

}