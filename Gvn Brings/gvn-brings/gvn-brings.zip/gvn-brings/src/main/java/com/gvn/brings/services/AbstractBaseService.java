package com.gvn.brings.services;

public abstract class AbstractBaseService {

}
