package com.gvn.brings.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gvn.brings.dao.OrderDao;
import com.gvn.brings.dao.RegistrationDao;
import com.gvn.brings.dto.OrderDto;
import com.gvn.brings.dto.RegistrationDto;
import com.gvn.brings.model.BrngOrder;

@Service("orderService")
public class OrderService extends AbstractBaseService{

	@Autowired
	private OrderDao orderDao;
	
	public List<OrderDto> getPayPercent(){
		return orderDao.getpayPercent();
	}
	public List<OrderDto> getIsPaidTypes(){
		return orderDao.getIsPaidTypes();
	}
	
	public int bookAnOrder(BrngOrder brngorder){
		return orderDao.bookAnOrder(brngorder);
	}
}
